'use client';
import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import SummaryMetrics from '../../components/SummaryMetrics';
import SchoolPerformanceChart from '../../components/SchoolPerformanceChart';
import ClassLevelChart from '../../components/ClassLevelChart';
import DrillDifficultyChart from '../../components/DrillDifficultyChart';
import TeacherEffectivenessChart from '../../components/TeacherEffectivenessChart';
import TrendAnalysisChart from '../../components/TrendAnalysisChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Dashboard() {
  const searchParams = useSearchParams();
  const startDate = searchParams.get('startDate');
  const endDate = searchParams.get('endDate');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`/api/drillData?startDate=${startDate}&endDate=${endDate}`);
        const result = await response.json();
        setData(result);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    if (startDate && endDate) {
      fetchData();
    }
  }, [startDate, endDate]);

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading dashboard data...</div>;
  }

  if (!data) {
    return <div className="flex justify-center items-center h-screen">No data available</div>;
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-2xl font-bold mb-6">
        School Drill Analytics: {startDate} to {endDate}
      </h1>

      <SummaryMetrics data={data.summary} />

      <Tabs defaultValue="schools">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="schools">Schools</TabsTrigger>
          <TabsTrigger value="classes">Classes</TabsTrigger>
          <TabsTrigger value="drills">Drills</TabsTrigger>
          <TabsTrigger value="teachers">Teachers</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>
        
        <TabsContent value="schools" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>School Performance Dashboard</CardTitle>
            </CardHeader>
            <CardContent>
              <SchoolPerformanceChart data={data.schoolPerformance} />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="classes" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Class Level Performance Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <ClassLevelChart data={data.classLevelPerformance} />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="drills" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Drill Difficulty Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <DrillDifficultyChart data={data.drillDifficulty} />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="teachers" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Teacher Effectiveness Report</CardTitle>
            </CardHeader>
            <CardContent>
              <TeacherEffectivenessChart data={data.teacherEffectiveness} />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="trends" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Drill Completion Trend Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <TrendAnalysisChart data={data.trendAnalysis} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
