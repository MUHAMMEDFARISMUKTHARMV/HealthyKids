'use client';
import React from 'react';
import { BarChart, XAxis, YAxis, Tooltip, Legend, Bar, CartesianGrid, ResponsiveContainer } from 'recharts';

export default function ClassLevelChart({ data }) {
  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="Class" />
          <YAxis yAxisId="left" label={{ value: 'Students / Drills', angle: -90, position: 'insideLeft' }} />
          <YAxis yAxisId="right" orientation="right" label={{ value: 'Achievement Rate (%)', angle: 90, position: 'insideRight' }} />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="TotalStudents" fill="#8884d8" name="Students" />
          <Bar yAxisId="left" dataKey="TotalDrillsAttempted" fill="#82ca9d" name="Drills Attempted" />
          <Bar yAxisId="left" dataKey="TotalDrillsAchieved" fill="#ffc658" name="Drills Achieved" />
          <Bar yAxisId="right" dataKey="AchievementRate" fill="#ff8042" name="Achievement Rate (%)" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}