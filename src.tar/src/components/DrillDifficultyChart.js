'use client';
import React from 'react';
import { BarChart, XAxis, YAxis, Tooltip, Legend, Bar, CartesianGrid, ResponsiveContainer, Cell } from 'recharts';

export default function DrillDifficultyChart({ data }) {
  // Generate colors based on class/grade level
  const getColor = (classLevel) => {
    const colors = {
      'K': '#8884d8',
      '1': '#83a6ed',
      '2': '#8dd1e1',
      '3': '#82ca9d',
      '4': '#a4de6c',
      '5': '#d0ed57',
      '6': '#ffc658'
    };
    return colors[classLevel] || '#ff8042';
  };

  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" domain={[0, 100]} label={{ value: 'Achievement Rate (%)', position: 'insideBottom', offset: -5 }} />
          <YAxis type="category" dataKey="DrillName" width={150} />
          <Tooltip 
            formatter={(value, name, props) => [`${value}%`, 'Achievement Rate']}
            labelFormatter={(label) => `Drill: ${label}`}
          />
          <Legend />
          <Bar dataKey="AchievementRate" name="Achievement Rate">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry.RecommendedClass)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}