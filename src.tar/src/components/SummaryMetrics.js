'use client';
import React from 'react';

export default function SummaryMetrics({ data }) {
  const metrics = [
    { 
      title: 'Total Schools', 
      value: data.totalSchools,
      icon: '🏫'
    },
    { 
      title: 'Total Students', 
      value: data.totalStudents,
      icon: '👨‍🎓'
    },
    { 
      title: 'Drills Attempted', 
      value: data.totalDrillsAttempted,
      icon: '🔄'
    },
    { 
      title: 'Average Achievement', 
      value: `${data.overallAchievementRate}%`,
      icon: '🏆'
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center space-x-2">
            <span className="text-2xl">{metric.icon}</span>
            <h3 className="text-lg font-medium text-gray-500">{metric.title}</h3>
          </div>
          <p className="text-3xl font-bold mt-2">{metric.value}</p>
        </div>
      ))}
    </div>
  );
}