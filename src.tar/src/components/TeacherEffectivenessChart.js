'use client';
import React from 'react';
import { ScatterChart, XAxis, YAxis, Tooltip, Legend, Scatter, CartesianGrid, ResponsiveContainer, ZAxis, Cell } from 'recharts';

export default function TeacherEffectivenessChart({ data }) {
  // Custom tooltip to show teacher name
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const teacher = payload[0].payload;
      return (
        <div className="bg-white p-2 border shadow">
          <p className="font-bold">{teacher.TeacherName}</p>
          <p>Success Rate: {teacher.SuccessRate}%</p>
          <p>Drills Monitored: {teacher.TotalDrillsMonitored}</p>
          <p>Students: {teacher.StudentsInstructed}</p>
          <p>Classes: {teacher.ClassesManaged}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
          <CartesianGrid />
          <XAxis 
            type="number" 
            dataKey="TotalDrillsMonitored" 
            name="Total Drills Monitored"
            label={{ value: 'Total Drills Monitored', position: 'insideBottom', offset: -5 }}
          />
          <YAxis 
            type="number" 
            dataKey="SuccessRate" 
            name="Success Rate"
            label={{ value: 'Success Rate (%)', angle: -90, position: 'insideLeft' }}
          />
          <ZAxis 
            type="number" 
            dataKey="StudentsInstructed" 
            range={[50, 400]} 
            name="Students"
          />
          <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomTooltip />} />
          <Legend />
          <Scatter name="Teachers" data={data} fill="#8884d8">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.SuccessRate > 80 ? '#82ca9d' : entry.SuccessRate > 70 ? '#ffc658' : '#ff8042'} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}