'use client';
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function TrendAnalysisChart({ data }) {
  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="Month" />
          <YAxis yAxisId="left" label={{ value: 'Number of Drills', angle: -90, position: 'insideLeft' }} />
          <YAxis yAxisId="right" orientation="right" label={{ value: 'Completion Rate (%)', angle: 90, position: 'insideRight' }} />
          <Tooltip />
          <Legend />
          <Line yAxisId="left" type="monotone" dataKey="DrillsStarted" stroke="#8884d8" name="Drills Started" />
          <Line yAxisId="left" type="monotone" dataKey="DrillsCompleted" stroke="#82ca9d" name="Drills Completed" />
          <Line yAxisId="right" type="monotone" dataKey="CompletionRate" stroke="#ff7300" name="Completion Rate (%)" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
