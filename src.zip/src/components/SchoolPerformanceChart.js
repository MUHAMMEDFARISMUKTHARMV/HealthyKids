'use client';
import React from 'react';
import { BarChart, XAxis, YAxis, Tooltip, Legend, Bar, CartesianGrid, ResponsiveContainer, Line, ComposedChart } from 'recharts';

export default function SchoolPerformanceChart({ data }) {
  // Sort by achievement rate for better visualization
  const sortedData = [...data].sort((a, b) => b.AchievementRate - a.AchievementRate);
  
  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={sortedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="SchoolName" angle={-45} textAnchor="end" height={70} />
          <YAxis yAxisId="left" label={{ value: 'Achievement Rate (%)', angle: -90, position: 'insideLeft' }} />
          <YAxis yAxisId="right" orientation="right" label={{ value: 'Total Drills', angle: 90, position: 'insideRight' }} />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="AchievementRate" fill="#8884d8" name="Achievement Rate (%)" />
          <Line yAxisId="right" type="monotone" dataKey="TotalDrillsAttempted" stroke="#ff7300" name="Total Drills" />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
